The FM.EXE file runs the VA's File Manager program from the data stored in
the Fileman.m file.  A limitation of this current edition, is that the
three files (msmws002.dll, fm.exe and Fileman.m) must be stored in the
following path.
 
  C:\Program Files\Micronetics\MSMWS\Program\
