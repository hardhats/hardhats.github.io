MUMPS.pas

This is a Delphi 3.0 unit which implements several standard Mumps functions:
$Piece (set and get)
$Find
$Extract (1 and 2 arguments)
$Length (1 and 2 arguments)
$TRanslate
$Justify (actually, expanded into LeftJustify and RightJustify)

I have used these for 'vanilla' purposes, but I have not attempted a rigorous
verification of their functions under boundary conditions.

Included is a Delphi 3.0 sample project, and the compiled executable.  The unit
MumpsEx.pas shows how the functions are called.

Michael Brutsch
webmaster@macewan.net
